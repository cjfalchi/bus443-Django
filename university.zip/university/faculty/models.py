from django.db import models

# Create your models here.

class Facultydetails(models.Model):
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    courseid = models.IntegerField()
    coursedescription = models.TextField()
    
class StudentInfo(models.Model):
    studentname = models.CharField(max_length=500)
    studentage = models.IntegerField()
    
class CommentData(models.Model):
    emailid = models.CharField(max_length=500)
    commentdata = models.TextField()
    
class Facultyawards(models.Model):
    facultyname = models.CharField(max_length=500)
    awardtype = models.CharField(max_length=500)
    
class Studentenroll (models.Model):
    studentname = models.CharField(max_length=500)
    coursename = models.CharField(max_length=500)
    
class Studentdetails(models.Model):
    studentid = models.IntegerField()
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    major = models.CharField(max_length=500)
    year = models.CharField(max_length=500)
    gpa = models.DecimalField(max_digits=5, decimal_places=2)

class Coursedetails(models.Model):
    courseid = models.IntegerField()
    coursetitle = models.CharField(max_length=500)
    coursename = models.CharField(max_length=500)
    sectioncode = models.IntegerField()
    coursedept = models.CharField(max_length=500)
    instructor = models.CharField(max_length=500)