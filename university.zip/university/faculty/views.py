from django.shortcuts import render
from django.http import HttpResponse
from faculty.models import Studentenroll, Studentdetails, Coursedetails
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required


# Create your views here.

@login_required
def dashboard (request):
    context = {'name': 'Falchi'}
    return render(request, 'faculty/dashboard.html', context)

@login_required
def studentdetails(request):
    studentdetails = Studentdetails.objects.all()
    paginator = Paginator(studentdetails, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'data':minidata}
    return render(request, 'faculty/studentdetails.html', context)

def enrollsave(request):
    if('sname' and 'cname' in request.GET):
        firstname = request.GET.get('sname')
        enrollinfo = request.GET.get('cname')
        dataobj = Studentenroll(studentname=firstname, coursename=enrollinfo)
        dataobj.save()


@login_required
def studentenroll(request):
    studentdata = Studentdetails.objects.all()
    coursename = Coursedetails.objects.all()
    enrolldata = Studentenroll.objects.all()
    context = {'student':studentdata, 'course':enrolldata, 'name':coursename}
    return render(request,'faculty/enroll.html', context)
    
@login_required
def coursedetails(request):
    coursedetails = Coursedetails.objects.all()
    paginator = Paginator(coursedetails, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'data':minidata}
    return render(request, 'faculty/coursedetails.html', context)

@login_required
def courses(request):
    facultydata = Facultydetails.objects.all()
    paginator = Paginator(facultydata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'data':minidata}
    return render(request, 'faculty/courses.html', context)



def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

#def facultydetails(request):
 #   firstname = 'Tyler'
  #  cursorobj = connection.cursor()
   # cursorobj.execute("select * from faculty_facultydetails where firstname= %s", [firstname])
    #facultydata = dictfetchall(cursorobj)
    #print(facultydata)
    #context = {'data':facultydata}
    #return render(request, 'faculty/facultydetails.html', context)
    
#Static files
# images
# css
# js
# documents
# videos