from django.contrib import admin
from faculty.models import Facultydetails, StudentInfo, Studentdetails, Coursedetails, Studentenroll

# Register your models here.


admin.site.register(Facultydetails)
admin.site.register(StudentInfo)
admin.site.register(Studentdetails)
admin.site.register(Coursedetails)
admin.site.register(Studentenroll)